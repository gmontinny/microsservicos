package com.ead.payment.enums;

public enum PaymentStatus {
    NOTSTARTED,
    PAYING,
    DEBTOR,
    CANCELED;
}
