package com.ead.payment.enums;

public enum PaymentControl {
    REQUESTED,
    EFFECTED,
    REFUSED,
    ERROR;
}
