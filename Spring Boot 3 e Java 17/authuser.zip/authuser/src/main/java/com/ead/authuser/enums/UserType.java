package com.ead.authuser.enums;

public enum UserType {
    ADMIN,
    STUDENT,
    INSTRUCTOR,
    USER;
}
