package com.ead.notification.enums;

public enum NotificationStatus {
    CREATED,
    READ;
}
