package com.ead.authuser.enums;

public enum PaymentControl {
    REQUESTED,
    EFFECTED,
    REFUSED,
    ERROR;
}
