package com.ead.payment.enums;

public enum ActionType {
    CREATE,
    UPDATE,
    DELETE;
}
