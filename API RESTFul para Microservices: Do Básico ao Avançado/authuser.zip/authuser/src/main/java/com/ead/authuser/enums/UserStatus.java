package com.ead.authuser.enums;

public enum UserStatus {
    ACTIVE,
    BLOCKED;
}
